import cartopy
import numpy as np
import matplotlib.pyplot as plt
import cartopy.crs as ccrs
import cartopy.feature as cfeature

num_points = 300
lats = np.random.uniform(-60, 60, num_points)  
lons = np.random.uniform(-180, 180, num_points)  
intensity = np.random.uniform(1, 10, num_points)  

fig = plt.figure(figsize=(12, 8))
ax = plt.axes(projection=ccrs.PlateCarree())
ax.add_feature(cfeature.COASTLINE, linewidth=0.5)
ax.add_feature(cfeature.BORDERS, linestyle=":", linewidth=0.5)
ax.add_feature(cfeature.LAND, facecolor="lightgreen")
ax.add_feature(cfeature.OCEAN, facecolor="lightblue")
scatter = ax.scatter(
    lons, lats, c=intensity, cmap="hot", s=50, alpha=0.6, transform=ccrs.PlateCarree()
)
cbar = plt.colorbar(scatter, orientation="vertical", pad=0.05)
cbar.set_label("Intensity")
plt.title("Geographical Heatmap Example", fontsize=16)
plt.show()
